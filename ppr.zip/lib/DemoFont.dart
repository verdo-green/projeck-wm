import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

class stu {
  String? id;
  String? name;
  String? imageUrl;
  String? details;

  stu({this.id, this.name, this.imageUrl, this.details});
}

class DemoFontPage extends StatefulWidget {
  _DemoFontPageState createState() => _DemoFontPageState();
}

class _DemoFontPageState extends State<DemoFontPage> {
  List<dynamic> students = [];

  @override
  void initState() {
    super.initState();
    loadJsonData();
  }

  // Load JSON data from the assets
  Future<void> loadJsonData() async {
    final String response = await rootBundle.loadString('assets/students.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      students = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'ข้อมูลตัวละคร',
          style: GoogleFonts.itim(fontSize: 22, color: Color(0xff000000)),
        ),
      ),
      body: students.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: students.length,
              itemBuilder: (context, index) {
                var student = students[index];

                return Card(
                  color: Color(0xff1b1b1b),
                  elevation: 10,
                  margin: EdgeInsets.all(10),
                  child: Padding(
                    padding: EdgeInsets.all(15),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                ListItemPage(student: student),
                          ),
                        );
                      },
                      leading: student['image'].startsWith('http')
                          ? Image.network(student['image'], width: 100)
                          : Image.asset(student['image'], width: 100),
                      title: Text(
                        'ประเภทตัวละคร : ${student['id']}',
                        style: GoogleFonts.itim(
                            fontSize: 15, color: Color(0xff5bffc4)),
                      ),
                      subtitle: Text(
                        student['name'],
                        style:
                            GoogleFonts.itim(fontSize: 20, color: Colors.blue),
                      ),
                      trailing: IconButton(
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          color: Color(0xffff5640),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  ListItemPage(student: student),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context); // กลับไปยังหน้าก่อนหน้า
        },
        backgroundColor: Colors.grey[300],
        child: Icon(
          Icons.arrow_back,
          color: Colors.black,
        ),
      ),
    );
  }
}

class ListItemPage extends StatelessWidget {
  final Map<String, dynamic> student;

  const ListItemPage({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1b1b1b),
      appBar: AppBar(
        title: Text(
          'ข้อมูลตัวละคร',
          style: GoogleFonts.k2d(fontSize: 18),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            student['image'].startsWith('http')
                ? Image.network(student['image'], width: 180)
                : Image.asset(student['image'], width: 180),
            SizedBox(height: 20),
            Text(
              'ชื่อ: ${student['name']} \nประเภทตัวละคร: ${student['id']} \nข้อมูลตัวละคร :${student['details']}',
              style: GoogleFonts.k2d(fontSize: 20, color: Color(0xff5bffc4)),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(context); // กลับไปยังหน้าก่อนหน้า
        },
        backgroundColor: Colors.grey[300],
        child: Icon(
          Icons.arrow_back,
          color: Colors.black,
        ),
      ),
    );
  }
}
